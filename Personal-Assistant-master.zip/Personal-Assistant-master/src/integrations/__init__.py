# Integration package initialization
