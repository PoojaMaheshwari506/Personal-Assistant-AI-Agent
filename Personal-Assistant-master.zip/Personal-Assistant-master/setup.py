from setuptools import setup
setup(
    name='PersonalAssistant',
    version='0.1.0',
)